import pyodide

async def autentificar_usuario(email, password):
    # URL del endpoint de la API
    url = "http://localhost:5000/inicioSesion/" + email + "/" + password
    # Preparar los datos en formato JSON
    #header = {"Content-Type": "application/json"}

    response = await pyodide.http.pyfetch(url=url, 
                            method="GET"
                            )
    
    data = await response.json()
    #response = requests.post(url, json=data, timeout=5, headers={"Content-Type": "application/json"})
    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Respuesta recibida:", data)
    else:
        print("Error en la solicitud:", data)
    
    return data['executed']
