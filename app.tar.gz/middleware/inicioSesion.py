import pyodide
import json

"""
async def autentificar_usuario(email, password):
    # URL del endpoint de la API
    url = "http://localhost:5000/inicioSesion/" + email + "/" + password
    # Preparar los datos en formato JSON
    #header = {"Content-Type": "application/json"}

    response = await pyodide.http.pyfetch(url=url, 
                            method="GET"
                            )
    
    data = await response.json()
    #response = requests.post(url, json=data, timeout=5, headers={"Content-Type": "application/json"})
    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Respuesta recibida:", data)
    else:
        print("Error en la solicitud:", data)
    
    return data['executed']
"""


async def autentificar_usuario(email, password):
    # URL del endpoint de la API para obtener información de un usuario
    url = f"https://unitime.netlify.app/.netlify/functions/autentificarUsuario"
    
    data = {
        'email': str(email),
        'password': str(password)
    }
    data_json = json.dumps(data)

    # await pyfetch(url)
    
    response = await pyodide.http.pyfetch(url=url,
                                          method="POST",
                                          body=data_json)

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Información del usuario recibida:", data)
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])
        
    return data