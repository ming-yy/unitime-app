import pyodide
import json


async def autentificar_usuario(email, password):
    # URL del endpoint de la API
    url = "https://unitime.netlify.app/.netlify/functions/autentificarUsuario"
    # Preparar los datos en formato JSON

    data = {
        'email': str(email),
        'password': str(password)
    }
    data_json = json.dumps(data)

    response = await pyodide.http.pyfetch(url=url, 
                            method="POST",
                            body=data_json
                            )
    
    data = await response.json()
    #response = requests.post(url, json=data, timeout=5, headers={"Content-Type": "application/json"})
    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Respuesta recibida:", data)
    else:
        print("Error en la solicitud:", data)
    
    return data['executed']
