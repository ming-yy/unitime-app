import pyodide
import json

async def update_usuario(email, user):
    # URL del endpoint de la API para actualizar un usuario
    url = f"https://unitime.netlify.app/.netlify/functions/updateUsuario"

    data = {
        "email": email,
        "user": user,
    }

    # Enviar una solicitud POST con los datos en formato JSON
    response = await pyodide.http.pyfetch(url=url, 
                        method="PATCH", 
                        body=json.dumps(data),
                        )

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Usuario actualizado correctamente. Respuesta recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)
