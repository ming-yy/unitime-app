import requests

def update_usuario(email, user):
    # URL del endpoint de la API para actualizar un usuario
    url = f"http://localhost:5000/usuarios/{email}"

    # Preparar los datos del usuario en formato JSON
    # 'user' es un diccionario con las claves apropiadas para actualizar, como 'nombre', 'password', etc.
    data = user

    # Enviar una solicitud PATCH con los datos en formato JSON
    response = requests.patch(url, json=data, headers={"Content-Type": "application/json"})

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Usuario actualizado correctamente. Respuesta recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)
