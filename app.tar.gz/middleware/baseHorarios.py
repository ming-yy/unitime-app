import pyodide
import json

"""
async def get_usuario(email):
    # URL del endpoint de la API para obtener información de un usuario
    url = f"http://localhost:5000/obtenerUsuario/{email}"
    
    data = {
        'clave1': 'valor1',
        'clave2': 'valor2'
    }
    data_json = json.dumps(data)
    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url,
                                          method="POST",
                                          body=data_json)

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Información del usuario recibida:", data)
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])
        
    return data
"""

async def get_usuario(email):
    # URL del endpoint de la API para obtener información de un usuario
    url = f"https://unitime.netlify.app/.netlify/functions/getUsuario"
    
    data = {
        'email': str(email),
    }
    data_json = json.dumps(data)

    # await pyfetch(url)
    
    response = await pyodide.http.pyfetch(url=url,
                                          method="POST",
                                          body=data_json)

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Información del usuario recibida:", data)
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])
        
    return data


async def get_carrera(name):
    # URL del endpoint de la API para obtener información de una carrera
    url = f"http://localhost:5000/carreras/{name}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Información de la carrera recibida:", data)
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])


async def get_asignatura(carreraCod):
    # URL del endpoint de la API para obtener información de asignaturas por código de carrera
    url = f"http://localhost:5000/asignaturas/{carreraCod}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Información de las asignaturas recibida:", data)
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])


async def get_asignatura_by_codeId(codigo):
    # URL del endpoint de la API para obtener información de una asignatura por su código
    url = f"http://localhost:5000/asignaturas/codigo/{codigo}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Información de la asignatura recibida:", data)
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])


async def get_asignatura_carrera_curso_semestre(name, curso, semestre):
    # URL del endpoint de la API para obtener información de asignaturas
    # basada en carrera, curso y semestre
    url = f"http://localhost:5000/asignaturas/{name}/{curso}/{semestre}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Información de las asignaturas recibida:", data)
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])


async def get_grupo_carrera_curso(name, curso):
    # URL del endpoint de la API para obtener información de grupos
    # basada en carrera y curso
    url = f"http://localhost:5000/grupos/{name}/{curso}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Información de los grupos recibida:", data)
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])


async def get_numCursos(name):
    # URL del endpoint de la API para obtener el número de cursos de una carrera
    url = f"http://localhost:5000/carreras/{name}/numCursos"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Número de cursos recibido:", data)
        return data
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])

async def autentificar_usuario(email, password):
    # URL del endpoint de la API
    url = f"http://localhost:5000/inicioSesion/{email}/{password}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    data = await response.json()
    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Respuesta recibida:", data)
    else:
        print("Error en la solicitud:", data['error'])

    return data['executed']

async def get_mi_horario(id):
    # URL del endpoint de la API para obtener información de un horario específico
    url = f"http://localhost:5000/horarios/{id}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Horario recibido:", data)
        return data
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])

async def get_misAsig(id):
    # URL del endpoint de la API para obtener información de asignaturas asociadas a un ID
    url = f"http://localhost:5000/misAsignaturas/{id}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Asignaturas recibidas:", data)
        return data
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])

async def get_asig(id):
    # URL del endpoint de la API para obtener información de una asignatura específica
    url = f"http://localhost:5000/asignaturas/{id}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Asignatura recibida:", data)
        return data
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])

async def rmv_horario_by_id_and_email(email, id):
    # URL del endpoint de la API para eliminar un horario específico de un usuario
    url = f"http://localhost:5000/usuarios/{email}/horarios/{id}"

    # Enviar una solicitud DELETE
    response = await pyodide.http.pyfetch(url=url, method="DELETE")

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Horario eliminado correctamente. Respuesta recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

async def get_semana_by_code(code):
    # URL del endpoint de la API para obtener información de una semana específica
    url = f"http://localhost:5000/semana/{code}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, method="GET")

    # Verificar y procesar la respuesta
    if response.status == 200:
        data = await response.json()
        print("Semana recibida:", data)
        return data
    else:
        data = await response.json()
        print("Error en la solicitud:", data['error'])

"""
def get_usuario(email):
    # URL del endpoint de la API para obtener información de un usuario
    url = f"http://localhost:5000/obtenerUsuario/{email}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información del usuario recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def get_carrera(name):
    # URL del endpoint de la API para obtener información de una carrera
    url = f"http://localhost:5000/carreras/{name}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información de la carrera recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def get_asignatura(carreraCod):
    # URL del endpoint de la API para obtener información de asignaturas por código de carrera
    url = f"http://localhost:5000/asignaturas/{carreraCod}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información de las asignaturas recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def get_asignatura_by_codeId(codigo):
    # URL del endpoint de la API para obtener información de una asignatura por su código
    url = f"http://localhost:5000/asignaturas/codigo/{codigo}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información de la asignatura recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def get_asignatura_carrera_curso_semestre(name, curso, semestre):
    # URL del endpoint de la API para obtener información de asignaturas
    # basada en carrera, curso y semestre
    url = f"http://localhost:5000/asignaturas/{name}/{curso}/{semestre}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información de las asignaturas recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)


def get_grupo_carrera_curso(name, curso):
    # URL del endpoint de la API para obtener información de grupos
    # basada en carrera y curso
    url = f"http://localhost:5000/grupos/{name}/{curso}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información de los grupos recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def get_numCursos(name):
    # URL del endpoint de la API para obtener el número de cursos de una carrera
    url = f"http://localhost:5000/carreras/{name}/numCursos"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Número de cursos recibido:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)


def add_misAsignaturas(misAsignaturas):
    # URL del endpoint de la API para agregar una lista de asignaturas
    url = "http://localhost:5000/misAsignaturas/add"

    # Preparar los datos en formato JSON
    # Asumiendo que 'misAsignaturas' es una lista de IDs o datos de asignaturas
    data = {
        "asignaturas": misAsignaturas
    }

    # Enviar una solicitud POST con los datos en formato JSON
    response = requests.post(url, json=data, headers={"Content-Type": "application/json"})

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Asignaturas agregadas correctamente. Respuesta recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def add_horario_user(horario):
    # URL del endpoint de la API para agregar un horario
    url = "http://localhost:5000/horarios/add"

    # Preparar los datos del horario en formato JSON
    # Asumiendo que 'horario' es un diccionario con la información del horario
    data = horario

    # Enviar una solicitud POST con los datos en formato JSON
    response = requests.post(url, json=data, headers={"Content-Type": "application/json"})

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Horario agregado correctamente. Respuesta recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def update_horario(email, id_horario):
    # URL del endpoint de la API para actualizar el horario de un usuario
    url = f"http://localhost:5000/usuarios/{email}/updateHorario"

    # Preparar los datos en formato JSON
    data = {
        "id_horario": id_horario
    }

    # Enviar una solicitud PATCH con los datos en formato JSON
    response = requests.patch(url, json=data, headers={"Content-Type": "application/json"})

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Horario actualizado correctamente. Respuesta recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def get_mi_horario(id):
    # URL del endpoint de la API para obtener información de un horario específico
    url = f"http://localhost:5000/horarios/{id}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información del horario recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def get_misAsig(id):
    # URL del endpoint de la API para obtener información de asignaturas asociadas a un ID
    url = f"http://localhost:5000/misAsignaturas/{id}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información de las asignaturas recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def get_asig(id):
    # URL del endpoint de la API para obtener información de una asignatura específica
    url = f"http://localhost:5000/asignaturas/{id}"

    # Enviar una solicitud GET
    response = requests.get(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Información de la asignatura recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)

def rmv_horario_by_id_and_email(email, id):
    # URL del endpoint de la API para eliminar un horario específico de un usuario
    url = f"http://localhost:5000/usuarios/{email}/horarios/{id}"

    # Enviar una solicitud DELETE
    response = requests.delete(url)

    # Verificar y procesar la respuesta
    if response.status_code == 200:
        print("Horario eliminado correctamente. Respuesta recibida:", response.json())
    else:
        print("Error en la solicitud:", response.status_code)
"""