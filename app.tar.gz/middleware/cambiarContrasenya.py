import pyodide
import json

async def get_usuario(email):
    # URL del endpoint de la API para obtener información de un usuario
    url = f"http://localhost:5000/usuario/get/byEmail/{email}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, 
                        method="GET",
                        )

    data = await response.json()
    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Información del usuario recibida:", data)
    else:
        print("Error en la solicitud:", data)
    return not(data['user'] == None)

async def update_password(email, new_password):
    # URL del endpoint de la API para actualizar la contraseña de un usuario
    url = f"http://localhost:5000/usuarios/{email}/updatePassword"

    # Preparar los datos en formato JSON
    header={"Content-Type": "application/json"}
    data = {
        "newPassword": new_password
    }

    # Enviar una solicitud POST con los datos en formato JSON
    response = await pyodide.http.pyfetch(url=url, 
                        method="PATCH", 
                        headers=header,
                        body=json.dumps(data),
                        )

    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Contraseña cambiada correctamente. Respuesta recibida:", response)
    else:
        print("Error en la solicitud:", response.status)

async def sendEmail(email):
    url = f"http://localhost:5000/usuarios/{email}/send"

    # Enviar una solicitud
    await pyodide.http.pyfetch(url=url)

