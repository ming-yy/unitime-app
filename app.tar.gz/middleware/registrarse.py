import pyodide
import json


async def registar_usuario(email, username, password):
    # URL del endpoint de la API para agregar usuarios
    url = "https://unitime.netlify.app/.netlify/functions/registrarUsuario"

    data = {
        "email": email,
        "username": username,
        "password": password,
    }
    
    # Enviar una solicitud POST con los datos en formato JSON
    response = await pyodide.http.pyfetch(url=url, 
                        method="POST", 
                        body=json.dumps(data),
                        )
    
    res = await response.json()

    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Usuario agregado correctamente. Respuesta recibida:", res)
    else:
        print("Error en la solicitud:", res)


async def get_usuario(email):
    # URL del endpoint de la API para obtener información de un usuario
    url = f"https://unitime.netlify.app/.netlify/functions/getUsuario"

    data = {
        "email": email,
    }

    # Enviar una solicitud POST con los datos en formato JSON
    response = await pyodide.http.pyfetch(url=url, 
                        method="POST", 
                        body=json.dumps(data),
                        )

    data = await response.json()
    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Información del usuario recibida:", data)
    else:
        print("Error en la solicitud:", data)
    return not(data['user'] == None)