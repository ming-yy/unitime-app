import pyodide
import json


async def registar_usuario(email, username, password):
    # URL del endpoint de la API para agregar usuarios
    url = "http://localhost:5000/registrarse"

    header={"Content-Type": "application/json"}
    data = {
        "email": email,
        "username": username,
        "password": password,
    }
    
    # Enviar una solicitud POST con los datos en formato JSON
    response = await pyodide.http.pyfetch(url=url, 
                        method="POST", 
                        headers=header,
                        body=json.dumps(data),
                        )
    #res = await response.json()
    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Usuario agregado correctamente. Respuesta recibida:", response)
    else:
        print("Error en la solicitud:", response.status)


async def get_usuario(email):
    # URL del endpoint de la API para obtener información de un usuario
    url = f"http://localhost:5000/usuario/get/byEmail/{email}"

    # Enviar una solicitud GET
    response = await pyodide.http.pyfetch(url=url, 
                        method="GET",
                        )

    data = await response.json()
    # Verificar y procesar la respuesta
    if response.status == 200:
        print("Información del usuario recibida:", data)
    else:
        print("Error en la solicitud:", data)
    return not(data['user'] == None)