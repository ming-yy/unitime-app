import flet as ft
import pages.inicioSesion as iniSes
import pages.registrarse as reg
import pages.cambiarContrasenya as camb
import pages.baseHorarios as baseHora
import pages.nuevaContrasenya as nueva


async def main(pg: ft.Page):
    paginaInicioSesion = iniSes.inicioSesion(pg)

    async def route_change(e: ft.RouteChangeEvent):
            
        if e.route == '/inicioSesion' or e.route == '/':
            print("INICIOSESION")

            print(pg.controls)
            #pg.controls.clear()
            await pg.clean_async()
            inicioSesion = iniSes.inicioSesion(pg)
            await pg.add_async(inicioSesion)

            await inicioSesion.update_async()
            print(pg.controls)

        elif e.route == '/registrarse':
            print("REGISTRARSE")

            print(pg.controls)
            #pg.controls.clear()
            await pg.clean_async()
            registrarse = reg.registrar(pg)
            await pg.add_async(registrarse)

            await registrarse.update_async()
            print(pg.controls)

        elif e.route == '/cambioContrasenya':
            print("CAMBIO CONTRASEYA")

            print(pg.controls)
            #pg.controls.clear()
            await pg.clean_async()
            cambio = camb.cambiarContrasenya(pg)
            await pg.add_async(cambio)
            await cambio.update_async()
            print(pg.controls)

        elif e.route.startswith('/nuevaContrasenya'):
            print("NUEVA CONTRASEÑA")

            # Extrae el correo de la ruta
            correo = await pg.client_storage.get_async("email")

            print(pg.controls)
            # pg.controls.clear()
            await pg.clean_async()

            # Crear una instancia de nuevaContrasenya con el correo extraído
            nueva_contrasena = nueva.nuevaContrasenya(pg, correo)
            await pg.add_async(nueva_contrasena)
            await nueva_contrasena.update_async()
            print(pg.controls)
        
        elif e.route == '/home':
            print("BASE HORARIOS")

            print(pg.controls)
            #pg.controls.clear()
            await pg.clean_async()
            baseHorarios = baseHora.baseHorarios(pg)
            await baseHorarios.chargeData()
            await pg.add_async(baseHorarios)
            await baseHorarios.update_async()
            print(pg.controls)


        await pg.update_async()

    
    pg.on_route_change = route_change
    print("HOLA")
    
    """
    if (pg.route == '/'):
        await pg.go_async('/inicioSesion')
    """

    #await pg.go_async('/inicioSesion')
    #await midInicioSesion.autentificar_usuario("a", "a")
    
    #await midRegistrarse.registar_usuario("b", "nombre", "bb")
    #pg.add(paginaInicioSesion.Pantalla)
    await pg.add_async(paginaInicioSesion)

    await pg.update_async()



ft.app(target=main, view=ft.AppView.WEB_BROWSER, port=8000)
