import flet as ft
import pages.inicioSesion as iniSes
import middleware.baseHorarios as baseSesion
import pages.horario as Horario
from pages.plantillas.plantillas import plantillas
#from db.models.misAsignaturas import misAsignaturas
#from db.models.horario import Horario as horarioNuevo
import middleware.cambiarContrasenya as CambiarContrasenya
#import middleware.cambiarUsuario as CambiarUsuario


class baseHorarios(ft.UserControl):  
    
    async def chargeData(self):
        
        email = await self.page.client_storage.get_async("email")
        self.cuenta = await baseSesion.get_usuario(email)
        self.usuario = self.cuenta['username']
        self.email = email
        self.admin = self.cuenta['soyAdmin']
        self.horarios = []

        # Obtenemos todos los objetos <<Horario>> de la cuenta del usuario
        for horario in self.cuenta['horarios']:
            self.horarios.append(await baseSesion.get_mi_horario(horario['$oid']))

        # Creacion de los diversos horarios en el gridview
        await self.visualizar_horarios(self.horarios)

        # Poner nombre de usuario correcto 
        self.userName(self.usuario)

        await self.update_async()

    def build(self):
        return self.Pantalla

    def __init__(self, page: ft.Page):
        super().__init__(expand=True)
        self.page = page    # Inicializa el atributo 'page'
        self.page.clean()
        self.page.route="/baseHorarios"
        self.page.bgcolor = ft.colors.WHITE

        self.cuenta = None
        self.usuario = None
        self.email = None
        self.admin = None
        self.horarios = []

        #page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        #page.vertical_alignment = ft.MainAxisAlignment.CENTER
        self.botonAnyadir.controls[0].on_click = self.on_create_click    # Botón de añadir horario          $$$

        # Le damos funcionalidad al botón para pasar a la pantalla de elegir Grupos
        self.Opciones.content.controls[1].content.on_click=self.on_next_click

        # Menu Dropdown para elegir el plan de estudio y el semestre
        self.SeleccionHorario.content.controls[1].controls[0].controls[1].on_change= self.dropdown_changed
        self.SeleccionHorario.content.controls[1].controls[1].controls[1].on_change= self.dropdown_changed

        # Objeto que construye un Horario a partir de: hora de inicio, hora final y asignaturas
        self.horario = Horario.horario(self.page,0,0)

        # Ventana PopUp correspondiente a la configuracion de un usuario
        self.configPopUp = ft.Container(
            content=ft.Column(
                controls=[
                    ft.Row(
                        controls=[
                            ft.Text("Configuración",size=40,color=ft.colors.BLACK,text_align=ft.MainAxisAlignment.CENTER),
                            ft.IconButton(
                                icon=ft.icons.CLOSE,
                                icon_color="black",
                                icon_size=50,
                                tooltip="Cerrar Configuración",
                                on_click=self.close_ConfigPopUp,
                            ),
                        ],
                        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
                    ),
                    ft.Column(
                        controls=[
                            ft.Text(value="Cambiar nombre",size=30,color=ft.colors.BLACK,text_align=ft.MainAxisAlignment.CENTER),
                            ft.TextField(hint_text="Nuevo nombre", autofocus=False,
                            width=400, height=40, text_size=20, border_color=ft.colors.BLACK54, 
                            focused_border_color=ft.colors.BLACK,),
                            ft.ElevatedButton(
                                "Confirmar",
                                width=130,
                                height=40,
                                style=ft.ButtonStyle(
                                    color=ft.colors.BLACK,
                                    bgcolor={ft.MaterialState.DEFAULT: '#FEC456'},
                                    side={ft.MaterialState.DEFAULT:
                                            ft.BorderSide(3, '#CB9D45')},
                                    shape={
                                        ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                                    },
                                ),
                                on_click = self.cambioNom
                            ),                     
                            ft.Container(width=20),
                            ft.Text(value="Cambiar contraseña",size=30,color=ft.colors.BLACK,text_align=ft.MainAxisAlignment.CENTER),
                            ft.TextField(hint_text="Nueva contraseña", autofocus=False,
                            width=400, height=40, text_size=20,can_reveal_password=True,password=True, border_color=ft.colors.BLACK54, 
                            focused_border_color=ft.colors.BLACK,),
                            ft.TextField(hint_text="Confirmar nueva contraseña", autofocus=False,
                            width=400, height=40, text_size=20,can_reveal_password=True,password=True, border_color=ft.colors.BLACK54, 
                            focused_border_color=ft.colors.BLACK,),
                            ft.Text("Las contraseñas no coinciden o estan vacias", size=15, color=ft.colors.RED_ACCENT_400,
                                        weight=ft.FontWeight.W_500, visible=False),
                            ft.Text("Contraseña cambiada exitosamente", size=15, color=ft.colors.RED_ACCENT_400,
                                        weight=ft.FontWeight.W_500, visible=False),
                            ft.ElevatedButton(
                                "Confirmar",
                                width=130,
                                height=40,
                                style=ft.ButtonStyle(
                                    color=ft.colors.BLACK,
                                    bgcolor={ft.MaterialState.DEFAULT: '#FEC456'},
                                    side={ft.MaterialState.DEFAULT:
                                            ft.BorderSide(3, '#CB9D45')},
                                    shape={
                                        ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                                    },
                                ),
                                on_click = self.cambioCon
                            ),
                        ],
                    ),
                ],
            ),
            bgcolor='#8986FF',
            expand=True,
            padding=20,
        )
        
        # Añadir funcionalidad al botón de abrir popup de configuración
        rutaBotonConfig = self.Menu_usuario.controls[0].items[1].content
        rutaBotonConfig.on_click = self.open_ConfigPopUp

        # Añadir funcionalidad al botón de logout
        logoutButton = self.Menu_usuario.controls[0].items[2].content
        logoutButton.on_click = self.logout_user

        # Contenedor de barra lateral izquierda
        barraLateral = ft.Container(
            content=ft.Column(
                        controls=[
                            ft.Column(
                                controls=[
                                    self.Menu_usuario,
                                    self.separador,
                                    self.Recientes,
                                    self.separador,
                                    self.botonAnyadir,
                                ],
                            ),
                        ],
                    ),
            width=250,
            bgcolor='#DCDBFF',
        )

        # Si es admin poner el Panel de administrador
        if self.admin is True:
            barraLateral.content.controls[0].controls.insert(3,self.Panel)

        # Crear un Stack para el GridView de horarios y que se sobreponga el AlertDialog de Configuración
        self.stack = ft.Container(
            content= ft.Stack( # Para que se ponga encima configuracion
                controls=[
                    self.ColeccionHorarios  # Añadir primero el GridView
                ],
                expand=True
            ),
            expand=True
        )

        # Coleccion principal de horarios
        self.SeccionPrincipal = ft.Container(
            content= ft.Column(
                controls=[
                    self.BarraBusqueda,
                    self.stack,
                ],
            ),
            expand=True,
            bgcolor='#FFFFFF'
        )

        # Añadimos funcionalidad a la barra de búsqueda de mis horarios
        rutaBarraBusqueda = self.SeccionPrincipal.content.controls[0]
        rutaBarraBusqueda.content.controls[3].on_submit = self.busqueda_horarios

        # Container que contiene los controls necesarios al crear un Horario
        self.CreacionHorario = ft.Container(
            content= ft.Stack(
                controls=[
                    ft.Column(
                        controls=[
                            self.SeleccionHorario,
                            self.EstadoSistema,
                            self.SeleccionAsignaturas,
                            self.separador,
                            self.Opciones,
                        ],
                    ),  
                ],
            ),
            expand=True,
            bgcolor='#FFFFFF'
        )
        
        # Container que contiene los controls necesarios para la visualizacion y confirmacion de la creacion de un horario
        self.FinHorario = ft.Container(
            content= ft.Stack(
                controls=[
                    ft.Column(
                        controls=[
                            self.horario.BarraNombre,
                            self.horario.Horario,
                            self.separador,
                            self.Opciones,
                        ],
                        spacing=20,
                    ),  
                ],
            ),
            padding=20,
            expand=True,
            bgcolor='#FFFFFF',
        )

        # Pantalla que tiene todo el contenido de baseHorarios
        pantalla = ft.Container(
            content=ft.Row(
                controls=[
                    barraLateral,
                    self.SeccionPrincipal,
                ],
                #vertical_alignment=ft.MainAxisAlignment.START,
            ),
            expand=True,
        )
        
        self.Pantalla = pantalla

        # Añadimos funcionalidad al botón HOME para volver a la pantalla de inicio de sesión
        rutaBotonHome = self.Pantalla.content.controls[0].content.controls[0].controls[2].controls[0]
        rutaBotonHome.on_click = self.return_home

        # Funcion asociada al AlertDialog de confirmacion de limpieza de horario en apartado de seleccion
        # usada en caso de cerrar este alertDialog
        async def limpiar_CreacionHorario(e):
            warningPopUp.open = False
            
            # Reasignacion de las acciones normales del boton
            self.Opciones.content.controls[1].content.on_click=self.on_next_click

            # Vaciar lista de asignaturas, inicio y fin
            self.listaAsignaturas = []
            self.listaFin = []
            self.listaInicio = []

            rutaDropDown_SeleccionHorario = self.Pantalla.content.controls[1].content.controls[0].controls[0].content.controls[1]
            rutaDropDown_SeleccionHorario.controls[0].controls[1].value=None    # Reiniciamos Dropdown Plan de estudio
            rutaDropDown_SeleccionHorario.controls[1].controls[1].value=None    # Reiniciamos Dropdown Curso
            
            # Actualizar estado sistema
            self.Pantalla.content.controls[1].content.controls[0].controls[1].content.controls[1].bgcolor=None
            self.Pantalla.content.controls[1].content.controls[0].controls[1].content.controls[2].bgcolor=None
            
            # Eliminar la creacion de Horario de los controles
            self.SeleccionAsignaturas.content.controls = []

            await self.update_async()


        # Funcion que cierra el AlertDialog de limpiar seleccion
        async def close_WarningPopUp(e):
            warningPopUp.open = False
            await self.update_async()


        # Crear un diálogo de alerta de limpieza de la seleccion del usuario a la hora de crear un horario.
        warningPopUp = ft.AlertDialog(
            modal=True,
            content=ft.Column(
                        controls=[
                            ft.Row(
                                controls=[
                                        ft.Image(src="../assets/icons/warning_icon.png", width=100, height=100,),
                                    ],
                                alignment=ft.MainAxisAlignment.CENTER,
                            ),
                            ft.Row(
                                controls=[
                                        ft.Text("¿Está seguro de que quiere reiniciar el proceso limpiando la selección?",size=20,color=ft.colors.WHITE,text_align=ft.TextAlign.CENTER,width=400,),
                                    ],
                                alignment=ft.MainAxisAlignment.CENTER,
                            ),
                        ],
                        width=500,
                        height=200,
                    ),
            actions=[
                ft.ElevatedButton(
                        text="    No    ",
                        height=60,
                        style=ft.ButtonStyle(
                            color=ft.colors.BLACK,
                            bgcolor={ft.MaterialState.DEFAULT: '#FEC456'},
                            side={ft.MaterialState.DEFAULT:
                                    ft.BorderSide(3, '#000000')},
                            shape={
                                ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                            },          
                        ),
                        on_click=close_WarningPopUp,
                    ),
                ft.ElevatedButton(
                        text="    Sí    ",
                        height=60,
                        style=ft.ButtonStyle(
                            color=ft.colors.BLACK,
                            bgcolor={ft.MaterialState.DEFAULT: '#C4C2FF'},
                            side={ft.MaterialState.DEFAULT:
                                    ft.BorderSide(3, '#000000')},
                            shape={
                                ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                            },          
                        ),
                        on_click=limpiar_CreacionHorario,
                    ),
            ],
            actions_alignment=ft.MainAxisAlignment.SPACE_AROUND,
        )


        # Funcion de apertura del warning pop up de la creacion de un horario
        async def open_WarningPopUp(e):
            page.dialog = warningPopUp
            warningPopUp.open = True
            await self.update_async()


        # Asignamos la apertura del warning al boton de limpiar en la creacion de un horario
        self.Opciones.content.controls[0].content.on_click=open_WarningPopUp


    # Función de cambio de nombre del popup de configuración
    async def cambioNom(self, e):
        # Se recoge el nombre nuevo
        nombre = self.configPopUp.content.controls[1].controls[1].value

        # Se limpia la variable como respuesta
        self.configPopUp.content.controls[1].controls[1].value = ""

        #CambiarUsuario.update_usuario(self.email, nombre)  # Se actualiza en la base
        self.usuario = nombre
        
        # Valor del texto del boton para mostrar el nombre del usuario
        self.Pantalla.content.controls[0].content.controls[0].controls[0].controls[0].content.controls[1].value=nombre
        # Valor del texto en el item del boton mencionado anteriormente
        self.Pantalla.content.controls[0].content.controls[0].controls[0].controls[0].items[0].content.controls[1].value=nombre
        await self.update_async()


    # Funcion de cambio de contraseña en el popup de configuracion
    async def cambioCon(self, e):
        self.configPopUp.content.controls[1].controls[7].visible=False
        self.configPopUp.content.controls[1].controls[8].visible=False
        pass1 = self.configPopUp.content.controls[1].controls[5].value
        pass2 = self.configPopUp.content.controls[1].controls[6].value

        # Verificamos si coinciden las 2 contraseñas introducidas
        if pass1 == pass2 and pass1 != "" and pass2 != "":
            await CambiarContrasenya.update_password(self.email, pass1)     # Actualizamos contraseña
            self.configPopUp.content.controls[1].controls[5].value = ""
            self.configPopUp.content.controls[1].controls[6].value = ""
            self.configPopUp.content.controls[1].controls[8].visible=True
        else:
            self.configPopUp.content.controls[1].controls[7].visible=True
        
        await self.page.update_async()   


    """
    def anyadir_horario(self, asig, horaIn, horaFin, nombre):
        ids = []
        for x in asig:     # Guardamos los ids de cada asignatura
            ids.append(x['_id'])
        
        # Se crea a la base de datos los datos de misAsignaturas
        newMisAsig = misAsignaturas(misAsignaturas = ids)

        # Se sube misAsignaturas y se obtiene el id de misAsignaturas recién subido
        idAsignaturas = str(baseSesion.add_misAsignaturas(newMisAsig))

        if (nombre == ""):
            nombre = "Horario sin nombre"

        # Se crea a la base de datos los datos de horario
        newHorario = horarioNuevo(nombre = nombre, misAsignaturas = idAsignaturas, horaFin = horaFin, horaIni = horaIn)
        
        # Se sube horario y se obtiene el id de horario recién subido
        idHorario = baseSesion.add_horario_user(newHorario)

        # Se añade a la lista de horarios de usuario
        self.horarios.append(baseSesion.get_mi_horario(idHorario))

        baseSesion.update_horario(self.email, idHorario)
        
        self.visualizar_horarios(self.horarios)
        
    """

    async def visualizar_horarios(self, listaDeHorarios):
        # Recuperar id del user
        # Hacer consulta de su array de horarios
        # Teniendo el id del horario, recoger el array de mis asignaturas
        # en mis asinaturas obtener el array de misAsignaturas obteniendo la
        # lista completa de ids de asignaturas.
        # A partir de ahi generar un array con el objeto a que apunta cada asignatura
        # self.ColeccionHorarios.content.controls = []       
        
        nuevosHorarios = []
        for horario in listaDeHorarios:     # Iteramos por nuestros horarios
            claveMisAsignaturas= horario['misAsignaturas']
            misAsig = await baseSesion.get_misAsig(str(claveMisAsignaturas['$oid']))

            print(misAsig)
            
            listaAsignaturas = []       # Array que tendrá id's de cada asignatura
            
            for i in misAsig['misAsignaturas']:     # Iteramos por asignaturas de cada horario
                listaAsignaturas.append(await baseSesion.get_asig(str(i['$oid'])))


            async def mostrarMiHorario(e,horario=horario,listaAsignaturas=listaAsignaturas):
                self.horario=Horario.horario(self.page,int(horario['horaIni']),int(horario['horaFin']))
                await self.horario.chargeData(listaAsignaturas)
                self.Pantalla.content.controls.remove(self.SeccionPrincipal)
                self.Pantalla.content.controls.append(self.FinHorario)
                # Escondemos botones de siguiente y limpiar
                self.Opciones.content.controls[0].content.visible=False
                self.Opciones.content.controls[1].content.visible=False
                await self.update_async()


            async def deleteHorario(e,horario=horario):
                await baseSesion.rmv_horario_by_id_and_email(self.email, horario["_id"]["$oid"])
                self.horarios.remove(horario)
                await self.visualizar_horarios(self.horarios)
                self.update_async()
            
            # Cada horario que habrá en el gridView de la colección de horarios
            horarioNuevo=ft.Container(on_click=mostrarMiHorario,height=200, width=200,
                                    bgcolor=ft.colors.AMBER_400,
                                    content=ft.Column(
                                        alignment=ft.MainAxisAlignment.CENTER,
                                        horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                                        controls=[
                                            ft.Text(value=horario['nombre'], color=ft.colors.BLACK, text_align=ft.TextAlign.CENTER,),
                                            ft.PopupMenuButton(
                                                items=[
                                                    ft.PopupMenuItem(
                                                        content=ft.Row(
                                                            alignment=ft.MainAxisAlignment.CENTER,
                                                            controls=[
                                                                ft.Text("Borrar", size=25, color=ft.colors.WHITE),
                                                            ],
                                                        ),
                                                        on_click=deleteHorario,
                                                    ),
                                                ],
                                            ),
                                        ]
                                    ),
                                )
            #self.ColeccionHorarios.content.controls.append(horarioNuevo)
            nuevosHorarios.append(horarioNuevo)

        self.ColeccionHorarios.content.controls = nuevosHorarios
        await self.update_async()
        
    # Función que pone el nombre de usuario en la barra lateral y en el popUp al pulsar sobre el "botón de usuario"
    def userName(self,usuario):
        if usuario is not None:
            self.Pantalla.content.controls[0].content.controls[0].controls[0].controls[0].content.controls[1].value=self.usuario
            self.Pantalla.content.controls[0].content.controls[0].controls[0].controls[0].items[0].content.controls[1].value=self.usuario


    # Funcion que abre el PopUp menu de configuracion 
    async def open_ConfigPopUp(self, e):
        # Llamar a esta función para mostrar el diálogo
        if self.configPopUp not in self.stack.content.controls:
            self.stack.content.controls.append(self.configPopUp)
            await self.update_async()

        if self.CreacionHorario in self.Pantalla.content.controls:
            if self.configPopUp not in self.CreacionHorario.content.controls:
                self.CreacionHorario.content.controls.append(self.configPopUp)
                await self.update_async()

        if self.FinHorario in self.Pantalla.content.controls:
            if self.configPopUp not in self.FinHorario.content.controls:
                self.FinHorario.content.controls.append(self.configPopUp)
                await self.update_async()

    # Funcion que cierra el PopUp de configuracion
    async def close_ConfigPopUp(self, e):
        # Llamar a esta función para cerrar el diálogo
        if self.configPopUp in self.stack.content.controls:
            self.stack.content.controls.remove(self.configPopUp)
            self.configPopUp.content.controls[1].controls[1].value = ""
            self.configPopUp.content.controls[1].controls[5].value = ""
            self.configPopUp.content.controls[1].controls[6].value = ""
            self.configPopUp.content.controls[1].controls[7].visible=False
            self.configPopUp.content.controls[1].controls[8].visible=False
            await self.update_async()

        if self.configPopUp in self.CreacionHorario.content.controls:
            self.CreacionHorario.content.controls.remove(self.configPopUp)
            self.configPopUp.content.controls[1].controls[1].value = ""
            self.configPopUp.content.controls[1].controls[5].value = ""
            self.configPopUp.content.controls[1].controls[6].value = ""
            self.configPopUp.content.controls[1].controls[7].visible=False
            self.configPopUp.content.controls[1].controls[8].visible=False
            await self.update_async()

        if self.configPopUp in self.FinHorario.content.controls:
            self.FinHorario.content.controls.remove(self.configPopUp)
            self.configPopUp.content.controls[1].controls[1].value = ""
            self.configPopUp.content.controls[1].controls[5].value = ""
            self.configPopUp.content.controls[1].controls[6].value = ""
            self.configPopUp.content.controls[1].controls[7].visible=False
            self.configPopUp.content.controls[1].controls[8].visible=False
            await self.update_async()

    # Volvemos a la pantalla de inicio
    async def return_home(self, e):
        if self.CreacionHorario in self.Pantalla.content.controls:
            # Actualizar estado sistema
            self.Pantalla.content.controls[1].content.controls[0].controls[1].content.controls[1].bgcolor=None
            self.Pantalla.content.controls[1].content.controls[0].controls[1].content.controls[2].bgcolor=None
            # Restablecer valor predeterminado de los dropdown
            self.Pantalla.content.controls[1].content.controls[0].controls[0].content.controls[1].controls[0].controls[1].value=None	
            self.Pantalla.content.controls[1].content.controls[0].controls[0].content.controls[1].controls[1].controls[1].value=None
            # Eliminar la creacion de Horario de los controles
            self.SeleccionAsignaturas.content.controls = []
            # Reasignacion de las acciones normales del boton
            self.Opciones.content.controls[1].content.on_click=self.on_next_click
            self.Pantalla.content.controls.remove(self.CreacionHorario)
            self.Pantalla.content.controls.append(self.SeccionPrincipal)
        elif self.FinHorario in self.Pantalla.content.controls:
            # Reasignacion de las acciones normales del boton
            self.Opciones.content.controls[1].content.on_click=self.on_next_click
            self.Opciones.content.controls[1].content.text="     Siguiente     "
            self.Opciones.content.controls[0].content.visible=True
            self.Pantalla.content.controls.remove(self.FinHorario)
            self.Pantalla.content.controls.append(self.SeccionPrincipal)
        self.close_ConfigPopUp(e)
        
        await self.update_async()

    # Funcion asignada a la creacion de un horario
    async def on_create_click(self, e):

        self.listaAsignaturas = []
        self.listaInicio = []
        self.listaFin = []

        # Mostramos botones de siguiente y limpiar
        self.Opciones.content.controls[0].content.visible=True
        self.Opciones.content.controls[1].content.visible=True
        
        if self.SeccionPrincipal in self.Pantalla.content.controls:
            self.Pantalla.content.controls.remove(self.SeccionPrincipal)

        if self.CreacionHorario in self.Pantalla.content.controls:
            self.Pantalla.content.controls.remove(self.CreacionHorario)
            
        self.Pantalla.content.controls.append(self.CreacionHorario)

        await self.update_async()


    def busqueda_horarios(self, e):
        nombre_a_buscar = e.control.value.lower()   
        nuevos_horarios = list(filter(lambda x: x['nombre'].lower().
                                        startswith(nombre_a_buscar.lower()), self.horarios))
        self.visualizar_horarios(nuevos_horarios)


    async def logout_user(self, e):
        # Cargar la página de inicio de sesión
        # Asegúrate de que 'inicioSesion' esté importado correctamente y se pueda instanciar aquí
        await self.page.clean_async()
        self.Pantalla.content.controls.pop(0)
        await self.page.go_async('/inicioSesion')
        await self.update_async()


    async def on_next_click(self, e):
        # Cambiar manejador de evento en el boton de siguiente
        self.Opciones.content.controls[1].content.on_click=self.on_next_click2

        # Vaciar lista de controles
        self.Pantalla.content.controls[1].content.controls[0].controls.remove(self.SeleccionAsignaturas)

        self.SeleccionAsignaturas.content.controls = []
        
        # Meter el container con grupos en vez de asignaturas
        self.Pantalla.content.controls[1].content.controls[0].controls.insert(2,self.SeleccionAsignaturas)

        planEstudio = self.Pantalla.content.controls[1].content.controls[0].controls[0].content.controls[1].controls[0].controls[1].value
        aux = await baseSesion.get_numCursos(planEstudio)
        for i in range(1,aux['numCursos']+1):
                # Consulta para saber las asignaturas por el plan de estudio, año y semestre seleccionado
                aux2 = await baseSesion.get_grupo_carrera_curso(planEstudio, i)
                # Lista vacia donde se meteran los botones de cada asignatura de cada año
                print(aux2)
                """
                mondongo = []
                for a in aux2:
                    # Creacion de boton por asignatura en el año
                    mondongo.append(plantillas.obtenerGrupoCarrera(str(a['codigo']),str(a['horaInicio']),str(a['horaFin']),self.listaInicio,self.listaFin))
                # Creacion del container con el año de la carrera y sus asignaturas
                containerAnyoCarrera = self.Pantalla.content.controls[1].content.controls[0].controls[2].content.controls

                Anyo = plantillas.obtenerAnyoCarrera(self.page,i, mondongo,containerAnyoCarrera)
                
                containerAnyoCarrera.append(Anyo)
                """

        # Actualizar estado sistema
        self.Pantalla.content.controls[1].content.controls[0].controls[1].content.controls[1].bgcolor="#D3DCE3"
        self.Pantalla.content.controls[1].content.controls[0].controls[1].content.controls[2].bgcolor="#D3DCE3"

        await self.update_async()


    async def on_next_click2(self, e):
        # Actualizar estado sistema
        self.Pantalla.content.controls[1].content.controls[0].controls[1].content.controls[1].bgcolor=None
        self.Pantalla.content.controls[1].content.controls[0].controls[1].content.controls[2].bgcolor=None
        # Restablecer valor predeterminado de los dropdown
        self.Pantalla.content.controls[1].content.controls[0].controls[0].content.controls[1].controls[0].controls[1].value=None	
        self.Pantalla.content.controls[1].content.controls[0].controls[0].content.controls[1].controls[1].controls[1].value=None
        # Eliminar la creacion de Horario de los controles
        self.SeleccionAsignaturas.content.controls = []
        
        self.Pantalla.content.controls.remove(self.CreacionHorario)

        self.Opciones.content.controls[1].content.on_click=self.on_finish_click
        self.Opciones.content.controls[1].content.text="     Crear Horario     "
        self.Opciones.content.controls[0].content.visible=False

        """
        if self.listaInicio == [] or self.listaFin == []:
            self.horario = Horario.horario(self.page,14,20,self.listaAsignaturas)
        else:
            self.horario = Horario.horario(self.page,int(min(self.listaInicio)),int(max(self.listaFin)),self.listaAsignaturas)
        """

        self.Pantalla.content.controls.append(self.FinHorario)

        await self.update_async()


    async def on_finish_click(self,e):    
        self.Pantalla.content.controls.remove(self.FinHorario)

        # Reasignacion de las acciones normales del boton
        self.Opciones.content.controls[1].content.on_click=self.on_next_click
        self.Opciones.content.controls[1].content.text="     Siguiente     "
        # Escondemos botones de siguiente y limpiar
        self.Opciones.content.controls[0].content.visible=False
        self.Opciones.content.controls[1].content.visible=False

        self.Pantalla.content.controls.append(self.SeccionPrincipal)
        listaAsig = self.listaAsignaturas
        horaIn = int(min(self.listaInicio))
        horaFi = int(max(self.listaFin))
        self.listaAsignaturas = []
        self.listaFin = []
        self.listaInicio = []
        nombre = self.horario.BarraNombre.content.controls[0].value

        self.anyadir_horario(listaAsig, horaIn, horaFi, nombre)

        await self.update_async()


    async def dropdown_changed(self, e):
        planEstudio = self.Pantalla.content.controls[1].content.controls[0].controls[0].content.controls[1].controls[0].controls[1].value
        periodoAcademico = self.Pantalla.content.controls[1].content.controls[0].controls[0].content.controls[1].controls[1].controls[1].value

        aux = {}
        if planEstudio and periodoAcademico:
            # Numero de años de la carrera
            aux = await baseSesion.get_numCursos(planEstudio)

            # Creacion del container con el año de la carrera y sus asignaturas
            containerAnyoCarrera = self.Pantalla.content.controls[1].content.controls[0].controls[2].content.controls= []

            for i in range(1,aux['numCursos']+1):
                # Consulta para saber las asignaturas por el plan de estudio, año y semestre seleccionado
                aux2 = await baseSesion.get_asignatura_carrera_curso_semestre(planEstudio, i, periodoAcademico)
                print(aux2)
                # Lista vacia donde se meteran los botones de cada asignatura de cada año
                """
                mondongo = []
                for a in aux2:
                    # Creacion de boton por asignatura en el año
                    mondongo.append(plantillas.obtenerAsignaturaCarrera(str(a['nombre']),str(a['codigo']),self.listaAsignaturas))

                Anyo = plantillas.obtenerAnyoCarrera(self.page,i, mondongo,containerAnyoCarrera)
                
                containerAnyoCarrera.append(Anyo)
                """

        await self.update_async()

    
    Search_icon = '../assets/icons/search_icon.png'
    Filter_icon = '../assets/icons/filter_icon.png'

    ColeccionHorarios = ft.Container(
        content=ft.GridView(
            expand=True,
            max_extent=150,
            child_aspect_ratio=1
        ),
        expand=True,
    )

    BarraBusqueda = ft.Container(
        content=ft.Row(
            controls=[
                ft.Container(width=10),
                #ft.Image(src=Search_icon, width=30, height=30,),
                ft.ElevatedButton(
                    bgcolor = '#FFFFFF',
                    content=ft.Row(
                        alignment=ft.MainAxisAlignment.CENTER,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            ft.Image(src=Search_icon, width=40, height=40, ),
                        ],
                    ),
                ),
                ft.Container(width=10),
                ft.TextField(hint_text="Buscar Horarios ...",
                            expand=True, height=50, text_size=12),
                ft.Container(width=10),
                ft.IconButton(
                    width=60,
                    height=60,
                    style=ft.ButtonStyle(
                        shape=ft.BeveledRectangleBorder(),
                    ),
                    content=ft.Row(
                        alignment=ft.MainAxisAlignment.CENTER,
                        vertical_alignment=ft.CrossAxisAlignment.CENTER,
                        controls=[
                            ft.Image(src=Filter_icon, width=60, height=60),
                        ],
                    ),
                ),
                ft.Container(width=10),
            ],
        ),
        bgcolor='#8986FF',
        border_radius=15,
        height=70,
    )

    User_icon = '../assets/icons/icon.png'

    Menu_usuario = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        width=250,
        height=90,
        controls=[
            ft.PopupMenuButton(
                content=ft.Row(
                    alignment=ft.MainAxisAlignment.CENTER,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Image(src=User_icon, width=70, height=70,
                        ),
                        ft.Text(value="Username", size=25,color=ft.colors.BLACK,),
                    ],
                    
                ),
                expand=True,
                items=[
                    ft.PopupMenuItem(
                        content=ft.Row(
                            controls=[
                                ft.Image(src=User_icon, width=70, height=70),
                                ft.Text("Username", size=25, color=ft.colors.WHITE),
                            ],
                        ),
                    ),
                    ft.PopupMenuItem(
                        content=ft.TextButton(
                            content=ft.Row(
                                controls=[
                                    ft.Text(value="Configuración", style="labelMedium",
                                    text_align="center",size=20,color=ft.colors.WHITE, width=230),                                    
                                ],
                            ),
                        ),
                    ),
                    ft.PopupMenuItem(
                        content=ft.TextButton(
                            content=ft.Row(
                                controls=[
                                    ft.Text(value="Cerrar sesión", style="labelMedium",
                                    text_align="center",size=20,color=ft.colors.WHITE, width=230),
                                ],
                            ),
                        ),
                    ),
                ]
            ),
        ]   
    )

    Home_icon = '../assets/icons/home_icon.png'
    
    Recientes = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.IconButton(
                width=250,
                height=80,
                style=ft.ButtonStyle(
                    shape=ft.BeveledRectangleBorder(),
                ),
                content=ft.Row(
                    alignment=ft.MainAxisAlignment.CENTER,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Image(src=Home_icon, width=40, height=40),
                        ft.Text("Home", size=25, color=ft.colors.BLACK,),
                    ],
                ),
            ),
        ],
    )

    Panel_icon = '../assets/icons/admin_icon.png'

    Panel = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.IconButton(
                width=250,
                height=80,
                style=ft.ButtonStyle(
                    shape=ft.BeveledRectangleBorder(),
                ),
                content=ft.Row(
                    alignment=ft.MainAxisAlignment.CENTER,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[
                        ft.Image(src=Panel_icon, width=40, height=40),
                        ft.Text("Panel de admin", size=25, color=ft.colors.BLACK,),
                    ],
                ),
            ),
        ],
    )

    Ayadir_icon = '../assets/icons/add_icon.png'
    
    botonAnyadir = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.ElevatedButton(
                content=ft.Row(
                    alignment=ft.MainAxisAlignment.CENTER,
                    controls=[
                        ft.Image(src=Ayadir_icon, width=30, height=30),
                        ft.Text("Nuevo horario", size=24, color=ft.colors.BLACK,),
                    ],
                ),
                bgcolor="#FEC456",
                width=230,
                height=60,
            ),
        ],
    )


    # Definición del separador (línea azul)
    separador = ft.Container(
        height=2,  # Ajusta el alto para el grosor de la línea
        bgcolor="#0041E9",  # Color de fondo azul
    )

    
    SeleccionHorario = ft.Container(
        content=ft.Column(
            controls=[
                ft.Text("Horarios: 2023/2024",size=40,color=ft.colors.BLACK,text_align=ft.MainAxisAlignment.CENTER),
                ft.Row(
                    controls=[
                         ft.Column(
                            controls=[
                                ft.Text("Plan de estudio",size=30,color=ft.colors.BLACK,text_align=ft.MainAxisAlignment.CENTER),
                                #ft.TextField(hint_text="Plan de estudio...", autofocus=False,
                                #    width=500, height=40, text_size=20,on_change=),
                                ft.Dropdown(
                                    hint_text="Plan de estudio",
                                    options=[
                                        ft.dropdown.Option("Ingeniería Informática"),
                                        ft.dropdown.Option("Ingeniería Electronica"),
                                        ft.dropdown.Option("Ingeniería Espacial"),
                                    ],
                                    autofocus=True,
                                ),
                            ],
                         ),
                         ft.Column(
                            controls=[
                                ft.Text("Periodo académico",size=30,color=ft.colors.BLACK,text_align=ft.MainAxisAlignment.CENTER),
                                #ft.TextField(hint_text="Periodo académico...", autofocus=False,
                                #    width=500, height=40, text_size=20,on_change= ),
                                ft.Dropdown(
                                    hint_text="Numero de cuatrimestre",
                                    options=[
                                        ft.dropdown.Option("1"),
                                        ft.dropdown.Option("2"),
                                    ],
                                    autofocus=True,
                                ),
                            ],
                         ),
                    ]
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        bgcolor='#8986FF',
        border_radius=15,
        padding=20,
    )


    EstadoSistema = ft.Container(
        padding=10,
        content= ft.Row(
             controls=[
                ft.Text(
                    "Selección de asignaturas",
                    size=20,
                    color=ft.colors.BLACK,
                    bgcolor="#D3DCE3"
                ),

                ft.Icon(
                    name=ft.icons.ARROW_FORWARD_IOS,
                    color="black",
                    size=20,
                ),
                
                ft.Text(
                    "Selección de grupos",
                    size=20,
                    color=ft.colors.BLACK
                ),
            ],
        ),
    )

    AsignaturaCarrera=ft.Column(
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.ElevatedButton(
                "Programacion 1",
                width=150,
                height=50,
                style=ft.ButtonStyle(
                    color=ft.colors.WHITE,
                    bgcolor={ft.MaterialState.DEFAULT: '#1B7746'},
                    shape={
                        ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                    },
                ),
            ),
        ],
    )

    SeleccionAsignaturas=ft.Container(
        padding=10,
        height=500,
        content=ft.Column(
                spacing=20,
                controls=[
                       
                ],
                scroll=ft.ScrollMode.AUTO,
            )
    )

    Opciones=ft.Container(
        content=ft.Row(
            controls=[
                ft.Container(
                    content=ft.ElevatedButton(
                        text="     Limpiar     ",
                        height=60,
                        style=ft.ButtonStyle(
                            color=ft.colors.BLACK,
                            bgcolor={ft.MaterialState.DEFAULT: '#F24822'},
                            side={ft.MaterialState.DEFAULT:
                                    ft.BorderSide(3, '#C13A1B')},
                            shape={
                                ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                            },          
                        ),
                    ),
                ),
                ft.Container(
                    content=ft.ElevatedButton(
                        text="     Siguiente     ",
                        height=60,
                        style=ft.ButtonStyle(
                            color=ft.colors.BLACK,
                            bgcolor={ft.MaterialState.DEFAULT: '#FEC456'},
                            side={ft.MaterialState.DEFAULT:
                                    ft.BorderSide(3, '#CB9D45')},
                            shape={
                                ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                            },          
                        ),
                    )
                ),
            ],
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        ),
        padding=20,
    )
