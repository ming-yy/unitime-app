import flet as ft
import re
import copy
import pages.inicioSesion as iniSes
import middleware.registrarse as Reg
import pages.plantillas.plantilla_comienzo as pantalla


class registrar(ft.UserControl):
    def __init__(self, page: ft.Page):
        super().__init__(expand=True)
        self.page = page
        self.page.route = '/registrarse'
        self.email = None
        self.user = None
        self.passwd = None
        self.passwdConf = None
        # Manejador de boton de registro
        self.BotonRegistrarse.controls[0].on_click=self.on_register_click

        # Manejador de campo user
        self.CampoUsuario.controls[0].on_change=self.on_user_init
        # Manejador de campo email
        self.CampoEmail.controls[0].on_change=self.on_email_init
        # Manejadores de campos de contraseñas
        self.CampoContraseña.controls[0].on_change=self.on_passwrd_init
        self.CampoContraseña2.controls[0].on_change=self.on_passwrd_confirm

        self.formularioRegistrarse = self.formulario
        # Asignamos la pantalla a la página
        self.Pantalla = copy.deepcopy(pantalla.plantilla_comienzo)
        self.Pantalla.content.controls.append(self.formularioRegistrarse)
        

    # Devuelve la pantalla de registro ya construida en init a Page
    def build(self):
        return self.Pantalla

    def es_correo_valido(self):
        # Expresión regular para validar un correo electrónico
        patron = r'^[\w\.-]+@[\w\.-]+\.\w+$'
        return re.match(patron, self.email) is not None

    # Devuelve <<True>> si ya hay un usuario con ese correo
    async def es_correo_registrado(self):
        # Buscar correo en base de datos
        if await Reg.get_usuario(self.email):
            return True
        else:
            return False
    

    async def on_register_click(self, e):
        direccionError = self.Pantalla.content.controls[0].content.controls[6]
        print(direccionError)
        # Si no son variables vacias
        instanciaInicioSesion = self.page.controls[0]
        if all([self.email, self.user, self.passwd, self.passwdConf]):
            # Si el correo es valido y no esta registrado
            if self.es_correo_valido() and not await self.es_correo_registrado():
                if self.passwd == self.passwdConf:
                    await Reg.registar_usuario(self.email, self.user, self.passwd)

                    # Volvemos a inicioSesion
                    print("HOLA")
                    await instanciaInicioSesion.update_async()
                    await self.page.go_async('/inicioSesion')
                    # Quitamos el formulario de registrarse y se pone el de inicio de sesión
                    #print(instanciaInicioSesion.Pantalla.content.controls)
                    #instanciaInicioSesion.Pantalla.content.controls.pop(-1)
                    #print(instanciaInicioSesion.Pantalla.content.controls)
                    #instanciaInicioSesion.Pantalla.content.controls.append(instanciaInicioSesion.formularioInicioSesion)
                else:
                    print("Error 1")
                    direccionError.controls[0].visible=True
                    direccionError.controls[0].value = "Las contraseñas no coinciden"
            else:
                print("Error 2")
                direccionError.controls[0].visible=True
                direccionError.controls[0].value = "El correo es invalido o ya esta registrado."
        else:
            print("Error 3")
            direccionError.controls[0].visible=True
            direccionError.controls[0].value = "Todos los campos son obligatorios"
        
        await self.update_async()
        await self.page.update_async()
        print("SDDKLJLKDJLADJLSD")



    def on_user_init(self,e):
        self.user = self.CampoUsuario.controls[0].value

    def on_email_init(self,e):
        self.email = self.CampoEmail.controls[0].value

    def on_passwrd_init(self,e):
        self.passwd = self.CampoContraseña.controls[0].value

    def on_passwrd_confirm(self,e):
        self.passwdConf = self.CampoContraseña2.controls[0].value
        


    TituloRegistrar = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.Text("Registrarse", size=30, color=ft.colors.BLACK,
                                        weight=ft.FontWeight.W_600),
                            ]
                        )
    MensajeDatos = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.Text("Introduzca su nombre de usuario, email y contraseña", size=15, color=ft.colors.BLACK,
                                        weight=ft.FontWeight.W_600),
                            ]
                        )
    CampoUsuario = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.TextField(label="Usuario", text_align=ft.TextAlign.LEFT,
                                             bgcolor=ft.colors.WHITE, border_radius=10,
                                             border_color=ft.colors.GREY, width=300,
                                             height=40, border=ft.InputBorder.OUTLINE,
                                             border_width=2,
                                             focused_border_color=ft.colors.BLACK, color='#000000'),
                            ],
                        )
    CampoEmail = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.TextField(label="Email", text_align=ft.TextAlign.LEFT,
                                             bgcolor=ft.colors.WHITE, border_radius=10,
                                             border_color=ft.colors.GREY, width=300,
                                             height=40, border=ft.InputBorder.OUTLINE,
                                             border_width=2, 
                                             focused_border_color=ft.colors.BLACK, color='#000000'),
                            ],
                        )
    CampoContraseña = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.TextField(label="Contraseña", text_align=ft.TextAlign.LEFT,
                                             password=True, can_reveal_password=True,
                                             bgcolor=ft.colors.WHITE, border_radius=10,
                                             border_color=ft.colors.GREY, width=300,
                                             height=40, border=ft.InputBorder.OUTLINE,
                                             border_width=2,
                                             focused_border_color=ft.colors.BLACK, color='#000000'),
                            ],
                        )
    CampoContraseña2 = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.TextField(label="Confirmar contraseña", text_align=ft.TextAlign.LEFT,
                                             password=True, can_reveal_password=True,
                                             bgcolor=ft.colors.WHITE, border_radius=10,
                                             border_color=ft.colors.GREY, width=300,
                                             height=40, border=ft.InputBorder.OUTLINE,
                                             border_width=2, 
                                             focused_border_color=ft.colors.BLACK, color='#000000'),
                            ],
                        )
    BotonRegistrarse = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.ElevatedButton(
                                    "     Registrarse     ",
                                    width=200,
                                    height=40,
                                    style=ft.ButtonStyle(
                                        color=ft.colors.BLACK,
                                        bgcolor={ft.MaterialState.DEFAULT: '#FEC456'},
                                        side={ft.MaterialState.DEFAULT:
                                                ft.BorderSide(3, '#CB9D45')},
                                        shape={
                                            ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                                        },          
                                    ),
                                )
                            ],   
                        )
    ErrorRegistro = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=43,
                            controls=[
                                ft.Text(size=15, color=ft.colors.RED_ACCENT_400,
                                        weight=ft.FontWeight.W_500, visible=False),
                            ],
                        )
    
    formulario=ft.Container(
            bgcolor='#8986FF',
            border_radius=10,
            alignment=ft.alignment.center,
            width=450,
            height=400,
            content=ft.Column(
                alignment=ft.MainAxisAlignment.CENTER,
                controls=[
                    TituloRegistrar,
                    MensajeDatos,
                    CampoUsuario,
                    CampoEmail,
                    CampoContraseña,
                    CampoContraseña2,                                
                    ErrorRegistro,
                    BotonRegistrarse,
                ],
            )
    )
