import flet as ft
import time
import copy
import pages.nuevaContrasenya as Inicio
import pages.pantallaCarga as Email_send
import middleware.cambiarContrasenya as Change
import pages.plantillas.plantilla_comienzo as pantalla

class cambiarContrasenya(ft.UserControl):
    def __init__(self, page: ft.Page):
        super().__init__(expand=True)
        self.page = page
        self.page.route = '/cambioContrasenya'
        self.user = None
        self.email = None
        # Pagina de Inicio
        self.paginaInicio = None
        # Manejador de cambio de contraseña
        self.BotonCambiar.controls[1].on_click = self.on_change_click
        # Manejador de campo email
        self.CampoEmail.controls[0].on_change=self.on_email_init

        self.formularioCambio = self.formulario
        # Asignamos la pantalla a la página
        self.Pantalla = copy.deepcopy(pantalla.plantilla_comienzo)
        self.Pantalla.content.controls.append(self.formularioCambio)

    # Devuelve la pantalla de registro ya construida en init a Page
    def build(self):
        return self.Pantalla

    async def es_correo_registrado(self):
        # Buscar correo en base de datos
        if await Change.get_usuario(self.email) is not None:
            return True
        else:
            return False

    def on_email_init(self,e):
        self.email = self.CampoEmail.controls[0].value

    async def on_change_click(self, e):
        if await self.es_correo_registrado():
            await self.page.clean_async()
            self.paginaChange = Email_send.pantallaCarga(self.page)
            await self.page.add_async(self.paginaChange.Pantalla)
            await self.page.update_async()
            
            # Peticion de enviar correo
            await Change.sendEmail(self.email)

            time.sleep(5)
            # Se vuelve al estado inicial tras el aviso
            await self.page.clean_async()
            self.Pantalla.content.controls.pop(0)
            self.ErrorInicioSesion.controls[0].visible = False
            await self.page.client_storage.set_async("email", str(self.email))
            await self.page.go_async(f'/nuevaContrasenya')
            await self.update_async()
        else:
            self.ErrorInicioSesion.controls[0].visible=True
        await self.page.update_async()
    
    TituloContra = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.Text("Cambiar mi contraseña\n", size=30, color=ft.colors.BLACK,
                                        weight=ft.FontWeight.W_600),
                            ]
                        )
    MensajeCambio = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.Text("Para cambiar su contraseña escriba su email", size=15, color=ft.colors.BLACK,
                                        weight=ft.FontWeight.W_600),
                            ]
                        )
    CampoEmail = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.TextField(label="Email", text_align=ft.TextAlign.LEFT,
                                             bgcolor=ft.colors.WHITE, border_radius=10,
                                             border_color=ft.colors.BLACK54, width=300,
                                             height=40, border=ft.InputBorder.OUTLINE,
                                             border_width=2, focused_border_color=ft.colors.BLACK,
                                             color='#000000'),
                            ],
                        )
    BotonCambiar = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.Container(height=125),
                                ft.ElevatedButton(
                                    "     Cambiar     ",
                                    width=200,
                                    height=40,
                                    style=ft.ButtonStyle(
                                        color=ft.colors.BLACK,
                                        bgcolor={ft.MaterialState.DEFAULT: '#FEC456'},
                                        side={ft.MaterialState.DEFAULT:
                                                ft.BorderSide(3, '#CB9D45')},
                                        shape={
                                            ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                                        },          
                                    ),
                                )
                            ],   
                        )
    ErrorInicioSesion = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=43,
                            controls=[
                                ft.Text("Email no registrado o incorrecto", size=15, color=ft.colors.RED_ACCENT_400,
                                        weight=ft.FontWeight.W_500, visible=False),
                            ],
                        )
    
    formulario = ft.Container(
                        bgcolor='#8986FF',
                        border_radius=10,
                        width=450,
                        height=400,
                        content=ft.Column(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                TituloContra,
                                MensajeCambio,
                                CampoEmail,
                                BotonCambiar,
                                ErrorInicioSesion,
                            ],
                        )
                    )