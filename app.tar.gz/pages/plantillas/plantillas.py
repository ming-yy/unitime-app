import flet as ft
import middleware.baseHorarios as Base

class Plantillas:
    def obtenerAnyoCarrera(self, page: ft.Page, anyo, asignaturas, pantalla):

        self.page = page
        def on_click_anyo(e):
            aux = pantalla[anyo-1].content.controls[1].visible
            pantalla[anyo-1].content.controls[1].visible=not aux
            self.page.update()

        AnyoCarrera=ft.Container(
            height=200,
            content=ft.Row(
                controls=[
                    ft.ElevatedButton(
                        text=str(anyo) + " º",
                        width=200,
                        height=200,
                        style=ft.ButtonStyle(
                            color=ft.colors.BLACK,
                            bgcolor={ft.MaterialState.DEFAULT: '#FEC456'},
                            side={ft.MaterialState.DEFAULT:
                                    ft.BorderSide(3, '#CB9D45')},
                            shape={
                                ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                            },
                        ),
                    ), 
                    ft.Container(
                        content=ft.Row(
                            spacing=20,
                            controls= asignaturas,
                            scroll=ft.ScrollMode.AUTO,
                            expand=True,
                            alignment=ft.MainAxisAlignment.SPACE_AROUND
                        ),
                        padding=20,
                        bgcolor="#FFCB83",
                        expand=True,
                        border_radius=15,
                    )
                ],
            ),
        )

        AnyoCarrera.content.controls[0].on_click=on_click_anyo

        return AnyoCarrera
    
    def obtenerAsignaturaCarrera(self, nombre, codigo, lista):

        def on_asignatura_click(e):
            res = Base.get_asignatura_by_codeId(codigo)
            if res in lista:
                lista.remove(res)
            else:
                lista.append(res)

        asignatura_button = ft.Chip(
                    label=ft.Text(value=nombre,),
                    width=250,
                    bgcolor='#1B7746',
                    shape=ft.RoundedRectangleBorder(radius=20),
                    on_select=on_asignatura_click,
                    selected_color='#058C44'
                )
            
        AsignaturaGrupoCarrera=ft.Column(
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[
                asignatura_button,
            ],
        )
        return AsignaturaGrupoCarrera
    
    def obtenerGrupoCarrera(self, codigo, horaInicio, horaFin, listaInicio, listaFin):

        def on_grupo_click(e):
            if horaInicio in listaInicio:
                listaInicio.remove(horaInicio)
            else:
                listaInicio.append(horaInicio)
                
            if horaFin in listaFin:
                listaFin.remove(horaFin)
            else:
                listaFin.append(horaFin)
            
        grupo_button = ft.Chip(
                    label=ft.Text(value=codigo,),
                    width=150,
                    bgcolor='#1B7746',
                    shape=ft.RoundedRectangleBorder(radius=20),
                    on_select=on_grupo_click,
                    selected_color='#058C44'
                )
        
        AsignaturaGrupoCarrera=ft.Column(
            alignment=ft.MainAxisAlignment.CENTER,
            controls=[
                grupo_button,
            ],
        )
        return AsignaturaGrupoCarrera

plantillas = Plantillas()