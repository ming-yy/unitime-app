#---------------------------------#---------------------------------#
#   IMPORTANTE: si se va a usar estas plantillas, se debe hacer
#               COPIA PROFUNDA. De lo contrario, lo que se tendrá
#               es un puntero.
#---------------------------------#---------------------------------#


import flet as ft


fondoPantallaInicioSesion = '../assets/images/bgSesion.png'

plantilla_comienzo = ft.Container(
            ft.Stack(
                [
                ],
            ),
            alignment=ft.alignment.center,
            image_src=fondoPantallaInicioSesion,
            image_fit=ft.ImageFit.COVER,
            expand = True,
        )