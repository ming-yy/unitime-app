import flet as ft
import copy
#import pages.baseHorarios as basHor
import middleware.inicioSesion as iniSesion
import pages.plantillas.plantilla_comienzo as pantalla
#import pages.cambiarContrasenya as Change


class inicioSesion(ft.UserControl):

    def __init__(self, page: ft.Page):
        # Inicializa el atributo 'page'
        super().__init__(expand=True)
        self.page = page
        self.page.route = '/inicioSesion'
        # Distintas paginas en relacion con Iniciar Sesion
        self.paginaBaseHorarios = None
        self.paginaChange = None

        # Manejador de login
        self.BotonInicioSesion.controls[0].on_click = self.on_login_click
        self.CampoEmail.controls[0].on_submit = self.on_login_click
        self.CampoContraseña.controls[0].on_submit = self.on_login_click

        # Manejador de registro
        self.BotonRegistrar.controls[1].on_click = self.on_register_click
        # Manejador de cambio de contraseña
        self.OpcionRecordarOlvidona.controls[1].on_click = self.on_remember_click
        # Layout de la app
        page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        page.vertical_alignment = ft.MainAxisAlignment.CENTER


        # Mostramos el formulario de Inicio de Sesión
        self.formularioInicioSesion = self.formulario


        # Asignamos la pantalla a la página
        self.Pantalla = copy.deepcopy(pantalla.plantilla_comienzo)      # SI NO SE HACE COPIA PROFUNDA, ES PUNTERO
        self.Pantalla.content.controls.append(self.formularioInicioSesion)


    # Devuelve la pantalla de inicio de sesión ya construida en init a Page
    def build(self):
        return self.Pantalla


    async def inicializarBaseHorarios(self,email):
        if self.paginaBaseHorarios is None:
            #self.paginaBaseHorarios = basHor.baseHorarios(self.page,email)     $$$$$$
            pass
        
    async def on_login_click(self, e):
        # Obtenemos email y contraseña
        direccion = self.Pantalla.content.controls[0].content
        email = direccion.controls[1].controls[0].value
        contrasenya = direccion.controls[2].controls[0].value
        #respuesta = iniSesion.autentificar_usuario(email, contrasenya)
        respuesta = await iniSesion.autentificar_usuario(email, contrasenya)
        print("InicioSesión: ", respuesta)
        direccion.controls[1].controls[0].value = ""
        direccion.controls[2].controls[0].value = ""
        
        if respuesta:
            #pass
            await self.page.client_storage.set_async("email", str(email))
            value = await self.page.client_storage.get_async("email")
            
            print(value)
            await self.page.go_async('/home')
            await self.update_async() 
            #self.inicializarBaseHorarios(email)
            #self.page.add(self.paginaBaseHorarios.Pantalla)
            #self.page.update()
        else:  # Opcionalmente puedes mostrar un mensaje de error si las credenciales son incorrectas
            self.ErrorInicioSesion.controls[0].visible = True
            await self.update_async()
        

    async def on_register_click(self, e):
        #await self.Pantalla.content.controls[0].clean_async()
        
        self.Pantalla.content.controls.pop(0)
        #self.paginaRegis = Reg.registrar(self.page)
        #self.Pantalla.content.controls.append(self.paginaRegis.pantalla)

        # Se crea instancia de registrar
        # Reg.registrar(self.page)
        #self.Pantalla.content.controls.append(Reg.registrar(self.page))
        self.ErrorInicioSesion.controls[0].visible = False
        await self.page.go_async('/registrarse')
        await self.update_async()


    async def on_remember_click(self, e):
        #await self.page.clean_async()
        self.Pantalla.content.controls.pop(0)
        #self.paginaChange = Change.cambiarContrasenya(self.page)       $$$$
        #await self.page.add_async(self.paginaChange.Pantalla)
        self.ErrorInicioSesion.controls[0].visible = False
        await self.page.go_async('/cambioContrasenya')
        await self.page.update_async()

    TituloInicioSesion = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.Text("Iniciar Sesión\n", size=30, color=ft.colors.BLACK,
                                        weight=ft.FontWeight.W_600),
                            ]
                        )
    CampoEmail = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.TextField(label="Email", label_style= ft.TextStyle(size=15, color=ft.colors.BLACK),
                                                text_align=ft.TextAlign.LEFT,
                                                bgcolor=ft.colors.WHITE, border_radius=10,
                                                border_color=ft.colors.BLACK54, width=300,
                                                height=40, border=ft.InputBorder.OUTLINE,
                                                border_width=2, color='#000000',
                                                prefix_icon=ft.icons.EMAIL_ROUNDED,
                                                focused_border_color=ft.colors.BLACK),
                            ],
                        )
    CampoContraseña = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.TextField(label="Contraseña", label_style=ft.TextStyle(size=15, color=ft.colors.BLACK),
                                             text_align=ft.TextAlign.LEFT,
                                             password=True, can_reveal_password=True,
                                             bgcolor=ft.colors.WHITE, border_radius=10,
                                             border_color=ft.colors.BLACK54, width=300,
                                             height=40, border=ft.InputBorder.OUTLINE,
                                             border_width=2, color='#000000',
                                             prefix_icon=ft.icons.KEY_ROUNDED,
                                             prefix_style=ft.TextStyle(color=ft.colors.BLACK),  # NO VA
                                             focused_border_color=ft.colors.BLACK),
                            ],
                        )
    OpcionRecordarOlvidona = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=43,
                            controls=[
                                ft.Checkbox(label="Recuérdame", value=False,
                                            fill_color=ft.colors.WHITE,
                                            check_color=ft.colors.BLACK),
                                ft.TextButton(text="Olvidé la contraseña",
                                              style=ft.ButtonStyle(color=ft.colors.BLACK))
                            ],
                        )
    BotonInicioSesion = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            controls=[
                                ft.ElevatedButton(
                                    "     Iniciar sesión     ",
                                    width=200,
                                    height=40,
                                    style=ft.ButtonStyle(
                                        color=ft.colors.BLACK,
                                        bgcolor={ft.MaterialState.DEFAULT: '#FEC456'},
                                        side={ft.MaterialState.DEFAULT:
                                                ft.BorderSide(3, '#CB9D45')},
                                        shape={
                                            ft.MaterialState.DEFAULT: ft.RoundedRectangleBorder(radius=20),
                                        },          
                                    ),
                                )
                            ],   
                        )
    ErrorInicioSesion = ft.Row(
                            alignment=ft.MainAxisAlignment.CENTER,
                            spacing=43,
                            controls=[
                                ft.Text("Email o contraseña no correctos", size=15, color=ft.colors.RED_ACCENT_400,
                                        weight=ft.FontWeight.W_500, visible=False),
                            ],
                        )

    BotonRegistrar = ft.Row(
                        alignment=ft.MainAxisAlignment.CENTER,
                        spacing=10,
                        controls=[
                            ft.Text("¿No estás registrado?", size=15, color=ft.colors.BLACK,),
                            ft.TextButton(text="Registrarse",
                                            style=ft.ButtonStyle(color=ft.colors.BLACK))
                        ],
                    )
    
    formulario = ft.Container(
                bgcolor='#8986FF',
                border_radius=10,
                alignment=ft.alignment.center,
                width=450,
                height=430,
                content=ft.Column(
                    alignment=ft.MainAxisAlignment.CENTER,
                    controls=[
                        TituloInicioSesion,
                        CampoEmail,
                        CampoContraseña,
                        OpcionRecordarOlvidona,
                        ErrorInicioSesion,
                        BotonInicioSesion,
                        BotonRegistrar,
                    ],
                )
            )
